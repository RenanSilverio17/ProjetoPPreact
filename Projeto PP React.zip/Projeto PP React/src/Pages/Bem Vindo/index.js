import React from "react";
impor { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function Bem Vindo() {
return (
    <View style={StyleSheet.container}>

    <View style={styles.containerLogo} >
        <Image
            source={require('../../assets/logo.png')}
            style={{ width: '100%' }}
            resizeMode="contain"
        />
    </View>

    </View>
 );
}

const styles = StyleSheet.create({
    container:{

    }
})