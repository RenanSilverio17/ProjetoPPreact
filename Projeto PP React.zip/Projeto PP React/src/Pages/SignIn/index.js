import React from "react";
impor { View, Text } from 'react-native';

export default function SignIn() {
return (
    <View>
    <Text>Tela de Login</Text>
    </View>
 );
}