import { createNativeStackNavigator } from "@react-navigation/native-stack";

import BemVindo from '../Pages/Bem Vindo'
import SignIn from '../Pages/Bem Vindo'

const Stack = createNativeStackNavigator();

export defaul function Routes(){
    return(
        <Stack.Navigator>
        <Stack.Screen
         name="Bem Vindo"
         component={BemVindo}
         options={{ headerShown: false }}
         />

         <Stack.Screen
         name="SignIn"
         component={SignIn}
         options={{ headerShown: false }}
         />
        </Stack.Navigator>
    )
}